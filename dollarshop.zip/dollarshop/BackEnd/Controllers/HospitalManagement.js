 import HospitalManagementModel from "../Models/HospitalManagement.js";
export const getContact=async(req,res)=>{
try{
    const patientMessages=await HospitalManagementModel.find();
    res.json(patientMessages);
}
catch(error){
console.log("not found my data")
}


};
export const createContact=async(req,res)=>{
// console.log("Post api reached");
// const result = req.body;
// console.log(result)
const patientName=req.body.patientName;
const patientNameInStringFormat=patientName.toString();

const Email=req.body.Email;
const EmailInStringFormat=Email.toString();

const Subject=req.body.Subject;
const SubjectInStringFormat=Subject.toString();

const Message=req.body.Message;
const MessageInStringFormat=Message.toString();

const newMessage= new HospitalManagementModel({
    patientName:patientNameInStringFormat,
    Email:EmailInStringFormat,
    Subject:SubjectInStringFormat,
    Message:MessageInStringFormat
});

try{
    await newMessage.save();
    res.json(newMessage);
}catch(error){
    console.log("Not...Saved")
}

};
