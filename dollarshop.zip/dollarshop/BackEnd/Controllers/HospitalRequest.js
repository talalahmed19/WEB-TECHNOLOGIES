import HospitalRequestModel from "../Models/HospitalRequest.js";
export const getRequest=async(req,res)=>{
try{
    const patientRequest=await HospitalRequestModel.find();
    res.json(patientRequest);
}
catch(error){
console.log("not found my data")
}


};
export const createRequest=async(req,res)=>{
// console.log("Post api reached");
// const result = req.body;
// console.log(result)
 const patientName=req.body.patientName;
 const patientNameInStringFormat=patientName.toString();

const Email=req.body.Email;
const EmailInStringFormat=Email.toString();

const Password=req.body.Password;
const PasswordInStringFormat=Password.toString();

 const City=req.body.City;
 const CityInStringFormat=City.toString();

 const Zip=req.body.Zip;
 const ZipInStringFormat=Zip.toString();

// const Program=req.body.Program;
// const ProgramInStringFormat=Program.toString();

// const Image=req.body.Image;
// const ImageInStringFormat=Image.toString();

const newRequest= new HospitalRequestModel({
     patientName:patientNameInStringFormat,
    Email:EmailInStringFormat,
    Password:PasswordInStringFormat,
    City:CityInStringFormat,
    Zip:ZipInStringFormat,
    // Program:ProgramInStringFormat,
    // Image:ImageInStringFormat
});

try{
    await newRequest.save();
    res.json(newRequest);
}catch(error){
    console.log("Not...Saved")
}

};
export const deleteUserData=async(req,res)=>{
    console.log(req.params._id);
    await HospitalRequestModel.deleteOne({_id:req.params.id})
}


export const getUserData = async (req, res) => {
    try {
        const User = await HospitalRequestModel.find({ _id: req.params.id });
        res.json(User);
    } catch (error) {
        console.log("not found any data");
    }
}

export const editUserData = async (req, res) => {
    console.log(req.body);
    const Signup = req.body;
    const Data = new HospitalRequestModel(Signup);
    try {
        await HospitalRequestModel.updateOne({ _id: req.params.id }, {
            $set: {
                 "patientName": req.body.patientName,
                 "Email": req.body.Email,
                "Password": req.body.Password,
                "City": req.body.City,
                 "Zip": req.body.Zip,
                // "Program": req.body.Program
                // "Image": req.body.Image
            }
        })
        res.json(Data)
    } catch (error) {
        console.log("error");
    }
}