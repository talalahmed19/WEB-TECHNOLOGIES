import mongoose from "mongoose";



const HospitalRequestStructure=mongoose.Schema({
    patientName:String,
        Email:String,
        Password:String,
        City:String,
        Zip:String,
        // Program:String,
        // Image:String
});

const HospitalRequestModel=mongoose.model('hospitalAppointment',HospitalRequestStructure);
export default HospitalRequestModel;