import mongoose from "mongoose";



const HospitalManagementStructure=mongoose.Schema({
    patientName:String,
        Email:String,
        Subject:String,
        Message:String
});

const HospitalManagementModel=mongoose.model('hospitalRecord',HospitalManagementStructure);
export default HospitalManagementModel;