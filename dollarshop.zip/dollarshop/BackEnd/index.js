import bodyParser from 'body-parser';
import cors from 'cors';
import mongoose from 'mongoose';
import express from 'express';
import Management from'./Routes/HospitalManagement.js';
import requestappointment from './Routes/HospitalRequest.js';
const app=express();


const url="mongodb+srv://talal:12345@cluster0.texwqns.mongodb.net/?retryWrites=true&w=majority";
mongoose.set('strictQuery', true);
mongoose.connect(url, {useNewUrlParser: true, useUnifiedTopology: true})
.then(()=>console.log("Connected to the database"));

app.listen(3000);


app.use(cors());
app.use(bodyParser.json( {extended:true} ));
app.use(bodyParser.urlencoded( {extended:true} ));
app.use("/HospitalManagement",Management);
app.use("/contact2",Management);
app.use("/HospitalRequest",requestappointment);
app.use("/request2",requestappointment);
app.use("/",requestappointment);
app.use("/EditUser", requestappointment);