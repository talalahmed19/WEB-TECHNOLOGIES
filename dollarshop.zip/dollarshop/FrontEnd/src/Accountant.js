import Admin from "./Admin";
function Accountant() {
    return ( 
        <div>
            <Admin/>
           <h1 style={{color:'grey',marginLeft:'100px',marginTop:'40px'}}> Acounts and Salary</h1>
            <img src="accnt.png" alt="..." class="img-thumbnail" style={{marginLeft:'270px',marginTop:'40px',height:'450px',width:'1000px'}}/>
            <img src="accnt2.jpg" alt="..." class="img-thumbnail" style={{marginLeft:'270px',marginTop:'70px',height:'500px',width:'1000px'}}/>
            
        </div>

     );
}

export default Accountant;